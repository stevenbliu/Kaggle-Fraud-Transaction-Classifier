# sdevinl.github.io
Just a website. Contains projects. Ways to access projects. My resume, contact details. Professional social media links.
